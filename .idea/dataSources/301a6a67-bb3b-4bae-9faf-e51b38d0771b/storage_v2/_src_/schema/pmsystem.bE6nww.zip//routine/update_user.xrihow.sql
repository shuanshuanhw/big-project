create
    definer = root@localhost procedure update_user(IN para12 varchar(200), IN para54 int)
BEGIN
update user set password=AES_ENCRYPT(para12,'hellokkshuanshuan') where id=para54;
END;

